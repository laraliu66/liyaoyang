package org.li.entity;

public class Transactions {
	
	private int  transactionID;  
	private int  TrandeID  ; 
	private int version     ;       // 类型： INT 
	private String  SecurityCode ;//  类型：String 
	private Long quantity;          //           类型： LONG 
	private int operation ;       // 类型：INT         1：INSERT   ，2：UPDATE    , 3 :CANCEL  
	private int buyORSell;       // 类型：INT         1：Buy           ，2 ：Sell     
	public int getTransactionID() {
		return transactionID;
	}
	public void setTransactionID(int transactionID) {
		this.transactionID = transactionID;
	}
	public int getTrandeID() {
		return TrandeID;
	}
	public void setTrandeID(int trandeID) {
		TrandeID = trandeID;
	}
	public int getVersion() {
		return version;
	}
	public void setVersion(int version) {
		this.version = version;
	}
	public String getSecurityCode() {
		return SecurityCode;
	}
	public void setSecurityCode(String securityCode) {
		SecurityCode = securityCode;
	}
	public Long getQuantity() {
		return quantity;
	}
	public void setQuantity(Long quantity) {
		this.quantity = quantity;
	}
	public int getOperation() {
		return operation;
	}
	public void setOperation(int operation) {
		this.operation = operation;
	}
	public int getBuyORSell() {
		return buyORSell;
	}
	public void setBuyORSell(int buyORSell) {
		this.buyORSell = buyORSell;
	}
	@Override
	public String toString() {
		return "Transactions [transactionID=" + transactionID + ", TrandeID=" + TrandeID + ", version=" + version
				+ ", SecurityCode=" + SecurityCode + ", quantity=" + quantity + ", operation=" + operation
				+ ", buyORSell=" + buyORSell + "]";
	}
	
	
}
